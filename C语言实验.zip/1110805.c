#include<stdio.h>
void catStr(char *str1,char *str2)
{
	while(*str1!='\0')
		str1++;
	while(*str2!='\0')
		*str1++=*str2++;
}
main()
{
	char a[50]="zgjl",b[20]="university";
	char *str1;
	char *str2;
	str1=a;
	str2=b;
	puts(str1);
	puts(str2);
	catStr(a,b);
	puts(str1);
}

