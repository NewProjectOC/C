#include<stdio.h>
main()
{
	char c1='T',c2='o',c3='d',c4='a',c5='y';
	c1-=22;
	c2-=22;
	c3-=22;
	c4-=22;
	c5-=22;
	printf("%c%c%c%c%c",c1,c2,c3,c4,c5);
}