#include<stdio.h>
main()
{
	float x,y;
	printf("x<2ʱ,y=(1+x)\n");
	printf("2=<x<4ʱ,y=1+(x-2)*(x-2)\n");
	printf("x>=4ʱ,y=(x-2)*(x-2)+(x-1)*(x-1)*(x-1)\n");
	printf("������x��ֵΪ:");
	scanf("%f",&x);
	if(x<2)
		{
			y=1+x;
			printf("%f",y);
		}
	else if(x>=2&&x<4)
		{
			y=1+(x-2)*(x-2);
			printf("%f",y);
		}
	else
		{
			y=(x-2)*(x-2)+(x-1)*(x-1)*(x-1);
			printf("%f",y);
		}
}