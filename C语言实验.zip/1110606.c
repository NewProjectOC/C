#include<stdio.h>
int lenStr(char str[])
{
	int i,j;
	j=0;
	for(i=0; ;i++)
	{
		if(str[i]!='\0')
			j++;
		else
			break;
	}
	return j;
}
void catStr(char str1[],char str2[])
{
	int i,m,n;
	m=lenStr(str1);
	n=lenStr(str2);
	for(i=0;i<=n;i++)
	{
		str1[m+i]=str2[i];
		if(str2[i]=='\0')
			break;
	}
	printf("%s ",str1);
	printf("%d\n",lenStr(str1));
}
void main()
{
	char str1[100]={"shfhh"},str2[100]={"fieg"};
	printf("%s ",str1);
	printf("%d\n",lenStr(str1));
	printf("%s ",str2);
	printf("%d\n",lenStr(str2));
	catStr(str1,str2);
}

