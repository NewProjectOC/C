#include<stdio.h>
int getMax(int x,int y,int z)
{
	int max;
	if(x>=y&&x>=z)
		max=x;
	else if(y>=x&&y>=z)
		max=y;
	else
		max=z;
	printf("The max is %d\n",max);
}
int getMin(int a,int b,int c)
{
	int min;
	if(a<=b&&a<=c)
		min=a;
	else if(b<=a&&b<=c)
		min=b;
	else
		min=c;
	printf("the min is %d\n",min);
}
main()
{
	int d,e,f,max,min;
	printf("������������:");
	scanf("%d%d%d",&d,&e,&f);
	getMax(d,e,f);
	getMin(d,e,f);
}

