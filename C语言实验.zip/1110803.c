#include<stdio.h>
void upCopy(char *old,char *new)
{	
	int i,j;
	j=0;
	for(i=0;i<20;i++)
	{
		if('A'<=*(old+i)&&*(old+i)<='Z')
		{
			*(new+j)=*(old+i);
			j++;
		}
	}
	*(new+j)='\0';
}
main()
{
	int i,j;
	char *old;
	char *new;
	char a[20]="zerCxJrHy";
	char b[10];
	old=a;
	new=b;
	for(j=0;j<20;j++)
		printf("%c",*(old+j));
	printf("\n");
	upCopy(old,new);
	for(i=0;i<20,*(new+i)!='\0';i++)
		printf("%c",*(new+i));
	printf("\n");
}
