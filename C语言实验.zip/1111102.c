#include<stdio.h>
#include<stdlib.h>
int main()
{
	FILE *fp;
	int i;
	int a[5]={61,15,135,35,89},b[5];
	float f=55.5678,ff;
	if((fp=fopen("TEXT.dat","wb+"))==NULL)
	{
		printf("cannot open the file\n");
		exit(0);
	}
	fwrite(&f,sizeof(float),1,fp);
	fwrite(a,sizeof(int),5,fp);
	fclose(fp);
	if((fp=fopen("TEXT.dat","rb"))==NULL)
	{
		printf("cannot open the file\n");
		exit(0);
	}	
	fread(&ff,sizeof(float),1,fp);
	fread(b,sizeof(int),5,fp);
	fclose(fp);
	printf("ff=%.3f\t",ff);
	for(i=0;i<5;i++)
	{
		printf("%d\t",b[i]);
	}
	printf("\n");
}
