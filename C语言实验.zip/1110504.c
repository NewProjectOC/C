#include<stdio.h>
#include<math.h>
main()
{
	int n,i;
	float pi,s;
	s=0;
	printf("������n��ֵ:");
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		s=s+1.0/(i*i);
	}
	pi=sqrt(6*s);
	printf("n=%d,pi=%f",n,pi);
}