#include<stdio.h>
int nulNum(int a,int b)
{
	if(a%b==0)
		return 1;
	else
		return 0;
}
int main()
{
	int a,b;
	printf("��������������:");
	scanf("%d%d",&a,&b);
	if(nulNum(a,b)==1)
		printf("%d is a multiple of %d\n",a,b);
	else
		printf("%d is not a multiple of %d\n",a,b);
}


