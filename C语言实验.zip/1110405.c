#include<stdio.h>
main()
{
	int s,num,flag;
	char grade;
	flag=1;
	printf("���������ĳɼ�(0��100������):");
	scanf("%d",&s);
	num=s/10;
	switch(num)
	{
		case 10:
		case 9:grade='A';break;
		case 8:grade='B';break;
		case 7:grade='C';break;
		case 6:grade='D';break;
		case 5:
		case 4:
		case 3:
		case 2:
		case 1:
		case 0:grade='E';break;
		default:grade='*';
	}
	printf("Your score is %d,your grade is %c\n",s,grade);


}