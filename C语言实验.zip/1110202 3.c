#include<stdio.h>
void main()
{
	char c1='P',c2='S',c3='Z',c4='I';
	printf("����ΪPSZI\n");
	c1+=22;
	c2+=22;
	c3+=22;
	c4+=22;
	printf("����Ϊ:%c%c%c%c\n",c1,c2,c3,c4);
}
