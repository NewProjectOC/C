#include<stdio.h>
struct person
{
	char name[10];
	int age;
};
main()
{
	struct person p1={"Michael",30};
	struct person p2={"Jack",40};
	struct person p3={"Paul",50};
	struct person *px1;
	struct person *px2;
	struct person *px3;
	px1=&p1;
	px2=&p2;
	px3=&p3;
	(*px1).age=p1.age;
	(*px2).age=p2.age;
	(*px3).age=p3.age;
	if(px1->age<=px2->age<=px3->age)
		printf("%s",px2->name);
	else if(px2->age<=px1->age<=px3->age)
		printf("%s",px1->name);
	else 
		printf("%s",px3->name);
	printf("\n");
}
