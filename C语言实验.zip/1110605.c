#include<stdio.h>
void intput(float score[4][5])
{
	int i,j;
	printf("����������ѧ�������ſγ̵ĳɼ�:\n");
	for(i=0;i<3;i++)
		for(j=0;j<4;j++)
			scanf("%f",&score[i][j]);
}

void compute (float score[4][5])
{
	int i,j;
	for(i=0;i<4;i++)
	{
		score[i][4]=0;
		score[i][4]=score[i][0]+score[i][1]+score[i][2]+score[i][3];
		for(j=0;j<5;j++)
		{
			score[3][j]=0;
			score[3][j]=(score[0][j]+score[1][j]+score[2][j])/3;
		}
	}
}

void output(float score[4][5])
{
	int i,j;
	for(i=0;i<4;i++)
		for(j=0;j<5;j++)
		{
			printf("%6.1f",score[i][j]);
			if((j+1)%5==0)
				printf("\n");
		}
}

main()
{
	float a[4][5];
	intput(a);
	compute(a);
	output(a);
}