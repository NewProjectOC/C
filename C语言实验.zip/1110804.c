#include<stdio.h>
main()
{
	int a,b,c,k;
	int *p1,*p2,*p3;
	printf("��������������:");
	scanf("%d%d%d",&a,&b,&c);
	p1=&a;
	p2=&b;
	p3=&c;
	if(a<b)
	{
		k=a;
		a=b;
		b=k;
	}
	if(a<c)
	{
		k=a;
		a=c;
		c=k;
	}
	if(b<c)
	{
		k=b;
		b=c;
		c=k;
	}	
	printf("%d %d %d\n",*p1,*p2,*p3);
}