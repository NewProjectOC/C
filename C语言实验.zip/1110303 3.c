#include<stdio.h>
main()
{
	char x1,x2,x3;
	x1=getchar();
	x2=getchar();
	x3=getchar();
	x1=x1-32;
	x2=x2-32;
	x3=x3-32;
	putchar(x1);
	putchar(x2);
	putchar(x3);
}