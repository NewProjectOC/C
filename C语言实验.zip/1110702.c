#include<stdio.h>
void primeNum(int x)
{
	int i;
	scanf("%d",&x);
	for(i=2;i<=(x/2);i++)
	{
		if(x%i!=0)
			continue;
		else
			break;
		
	}
	if(i>x/2)
		printf("x is a prime number\n");
	else
		printf("x is not a prime number\n");
}
int x;
main()
{
	printf("������x��ֵ:");
	primeNum(x);
}