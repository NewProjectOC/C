#include<stdio.h>
#include<math.h>
main()
{
	int a,b,i,sum;
	i=1,b=2,a=1000,sum=0;
	for(a=1000;a>1;a--)
	{
		for(b=2;a%b!=0;b++)
		{
			if(b>=sqrt(a))
			{
				if(i==1)
				printf("%d",a);
				else printf("+%d",a);
				sum=sum+a;
				i++;
				break;
			}
		}
		if(i==11) break;
	}
		printf("=%d\n",sum);
}