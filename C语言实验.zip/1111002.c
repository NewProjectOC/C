#include<stdio.h>
#define TRANSF 1
main()
{
	int a[4],i=0;
	int x;
	printf("������һ��4λ��:");
	scanf("%d",&x);
	#if TRANSF
	{
		a[0]=((x%1000)%100)%10;
		a[1]=(((x%1000)%100)-a[0])/10;
		a[3]=x/1000;
		a[2]=x/100-a[3]*10;
		for(i=0;i<4;i++)
			if(a[i]%2==0)
				a[i]+=1;
			else
				a[i]-=1;
		printf("����Ϊ:%d\n",a[3]*1000+a[2]*100+a[1]*10+a[0]);
	}
	#elif !TRANSF
	{
		printf("%d\n",x);
	}
	#endif
}