#include<stdio.h>
#include<stdlib.h>
struct student
{
	char num[10];
	char name[10];
	float math;
	float eng;
	float com;
	float ave;
};
int main()
{
	FILE *fp;
	struct student students[5];
	int i;
	printf("����5λͬѧ��ѧ�ţ������ͳɼ�\n");
	for(i=0;i<5;i++)
	{
		scanf("%s%s%f%f%f",&students[i].num,&students[i].name,&students[i].math,&students[i].eng,&students[i].com);
		students[i].ave=(students[i].math+students[i].eng+students[i].com)/3.0;
	}
	if((fp=fopen("stuinfo.txt","w"))==NULL)
	{
		printf("cannot open the file\n");
		exit(0);
	}
	for(i=0;i<5;i++)
	{
		fprintf(fp,"%s %s %.2f %.2f %.2f %.2f\n",students[i].num,students[i].name,students[i].math,students[i].eng,students[i].com,students[i].ave);
	}
	fclose(fp);
}