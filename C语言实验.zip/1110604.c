#include<stdio.h>
void paixu(int a[],int n)
{
	int h,i,j;
	for(i=0;i<20;i++)
		for(j=0;j<20;j++)
		{
			if(a[1+j]<a[j])
			{
				h=a[1+j];
				a[1+j]=a[j];
				a[j]=h;
			}
		}
	for(i=0;i<n;i++)
		printf("%d ",a[i]);
	printf("\n");
}
int searchbyMid(int m,int b[],int n)
{
	int i,j,k;
	i=0;
	k=n-1;
	while(i<=k)
	{
		j=(i+k)/2;
		if(m==b[j])
			return j;
		else if(m<b[j])
			k=j-1;
		else
			i=j+1;
	}
	return -1;
}
void main()
{
	int a[]={5,8,15,90,54,3,84,19,30,6,77,66,10,22,60,48,91,25,40,47};
	int num=0,i;
	printf("������Ҫ���ҵ�����:");
	scanf("%d",&i);
	paixu(a,20);
	num=searchbyMid(i,a,20);
	if (num!=-1)
		printf("�����ҵ����������е�%d��λ��\n",num);
	else
		printf("Not Found\n");
}


