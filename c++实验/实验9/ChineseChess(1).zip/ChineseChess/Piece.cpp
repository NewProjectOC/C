// Piece.cpp: implementation of the CPiece class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ChineseChess.h"
#include "Piece.h"
#include "Chessboard.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

// ������ĳ�Ա����

// ������Ĺ��캯������ʼ������
CPiece::CPiece()
{
	m_bAlive = false;
	m_bSelected = false;
	m_bRed = true;
	m_nCol = 0;
	m_nRow = 0;
	m_sName = _T("");
	m_nType = PIECE_TYPE_NULL;
}

// ������������
void CPiece::SetProperties(bool red, int col, int row, LPCSTR name, int type)
{
	m_bAlive	= true;
	m_bSelected = false;
	m_bRed		= red;
	m_nCol		= col;
	m_nRow		= row;
	m_sName		= name;
	m_nType		= type;
}


// �����ӷŵ�ָ��λ��
void CPiece::MoveTo(int col, int row, CChessboard &board)
{
	board.SetPieceOff(CPoint(m_nCol, m_nRow) );
	board.SetPieceOn(GetID(),CPoint(col, row));
	m_bSelected = FALSE;
	m_nCol		= col;
	m_nRow		= row;
}
