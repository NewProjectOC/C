// Chessboard.cpp: implementation of the CChessboard class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ChineseChess.h"
#include "Chessboard.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CChessboard::CChessboard()
{
	SetBoardRect();
	ClearPieces();
}

void CChessboard::SetBoardRect(int left /*= 100 */ , int top /*= 50 */ , int dx /*= 50 */ , int dy /*= 50 */ )
{
	m_ndx = dx;
	m_ndy = dy;
	m_nLeft = left;
	m_nTop = top;
	m_nRight = m_nLeft + m_ndx * 8; //500
	m_nBottom = m_nTop + m_ndy * 9; //500
	int half = m_ndx / 2;

	//�췽���ϰ벿��
	m_redRect.SetRect(m_nLeft - half, m_nTop - half, m_nRight + half, m_nTop + m_ndy * 4 + half);

	//�ڷ����°벿��
	m_balckRect.SetRect(m_nLeft - half, m_nTop + m_ndy * 5 - half, m_nRight + half, m_nTop + m_ndy * 9 + half);

	m_boardRect.SetRect(m_nLeft - half, m_nTop - half, m_nRight + half, m_nBottom + half);

}

void CChessboard::SetBoardRect2(int left, int top, int width, int height)
{
	m_ndx = width / 9;
	m_ndy = height / 10;
	int nExtendX = m_ndx/2;// (width - (m_nRight - m_nLeft)) / 2;
	int nExtendY = m_ndy/2;// (height - (m_nBottom - m_nTop)) / 2;
	m_nLeft = left+nExtendX;
	m_nTop = top+nExtendY;
	m_nRight = m_nLeft + m_ndx * 8; //500
	m_nBottom = m_nTop + m_ndy * 9; //500

	//�췽���ϰ벿��
	m_redRect.SetRect(m_nLeft - nExtendX, m_nTop - nExtendY, m_nRight + nExtendX, m_nTop + m_ndy * 4 + nExtendY);

	//�ڷ����°벿��
	m_balckRect.SetRect(m_nLeft - nExtendX, m_nTop + m_ndy * 5 - nExtendY, m_nRight + nExtendX, m_nTop + m_ndy * 9 + nExtendY);

	m_boardRect.SetRect(m_nLeft - nExtendX, m_nTop - nExtendY, m_nRight + nExtendX, m_nBottom + nExtendY);

}

// ȡ�����ϸ�����������
CPoint CChessboard::GetPosition(int col, int row)const
{
	CPoint point;
	point.x = m_nLeft+col*m_ndx;
	point.y = m_nTop+row*m_ndy;
	return point;
}

//�����������꣬���������ϵ�����
CPoint CChessboard::GetChessPosition(const CPoint &point)const
{
	CPoint chessPos(-1, -1);
	if (m_boardRect.PtInRect(point) == FALSE)
		return chessPos;
	else
	{
		chessPos.x = point.x - m_nLeft;
		chessPos.y = point.y - m_nTop;
		chessPos.x = chessPos.x / (double)m_ndx + 0.5;
		chessPos.y = chessPos.y / (double)m_ndy + 0.5;
		return chessPos;
	}
}




// �������λ���ϵ�����
void CChessboard::ClearPieces()
{
	for (int row = 0; row < 10; row++)
	{
		memset(m_board[row], -1, 9 * sizeof(char));
	}

}
