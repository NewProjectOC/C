// ChineseChessDlg.h : header file
//

#if !defined(AFX_CHINESECHESSDLG_H__72442016_F3B0_4CB4_A7FD_B3DEAAB8679D__INCLUDED_)
#define AFX_CHINESECHESSDLG_H__72442016_F3B0_4CB4_A7FD_B3DEAAB8679D__INCLUDED_

#include "Chessboard.h"	// Added by ClassView
#include "Piece.h"
#include "Player.h"
#include "Render.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CChineseChessDlg dialog

class CChineseChessDlg : public CDialog
{
// Construction
public:
	void InitGame();
	void ShowInfo();
	CChineseChessDlg(CWnd* pParent = NULL);	// standard constructor
	~CChineseChessDlg();

// Dialog Data
	//{{AFX_DATA(CChineseChessDlg)
	enum { IDD = IDD_CHINESECHESS_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChineseChessDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CChineseChessDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CChessboard	m_chessboard;			// ����
	CFont	m_fontInfo;		//��ʾ��Ϣ������

	CPlayer m_playerRed;	//�췽
	CPlayer m_playerBlack;	//�ڷ�

	CRender	m_render;	//������ʾ��������̡�����

	CDC		m_pMemDC;
	CBitmap m_pBitmap;


public:
	afx_msg void OnBnClickedButtonStart();
	CString m_strBlackInfor; //��Ϣ
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnDrawChessboard();
	afx_msg void OnUpdateDrawChessboard(CCmdUI *pCmdUI);
	afx_msg void OnDrawChessboardByBitmap();
	afx_msg void OnUpdateDrawChessboardByBitmap(CCmdUI *pCmdUI);
	afx_msg void OnDrawChessboard3d();
	afx_msg void OnUpdateDrawChessboard3d(CCmdUI *pCmdUI);
	afx_msg void OnInitMenuPopup(CMenu* pPopupMenu, UINT nIndex, BOOL bSysMenu);
	//����
	afx_msg void OnBnClickedButtonBackward();

	// �췽Ӯ�ľ���
	int m_nRedWinNum;
	// �췽��ľ���
	int m_nRedLoseNum;
	// �췽ʤ��
	int m_nRedWinRatio;
	CString m_strRedInfor;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHINESECHESSDLG_H__72442016_F3B0_4CB4_A7FD_B3DEAAB8679D__INCLUDED_)
