// ChineseChessDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ChineseChess.h"
#include "ChineseChessDlg.h"
#include "ChessRule.h"
#include "Player.h"
#include "Render.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChineseChessDlg dialog

CChineseChessDlg::CChineseChessDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CChineseChessDlg::IDD, pParent)
	
	, m_strBlackInfor(_T(""))
	, m_nRedWinNum(0)
	, m_nRedLoseNum(0)
	, m_nRedWinRatio(0)
	, m_strRedInfor(_T(""))
	, m_playerRed(true)
	, m_playerBlack(false)
{

	InitGame();

	//{{AFX_DATA_INIT(CChineseChessDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

CChineseChessDlg::~CChineseChessDlg()
{
	m_pBitmap.DeleteObject();
	m_pMemDC.DeleteDC();
}


void CChineseChessDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CChineseChessDlg)
	// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
	DDX_Text(pDX, IDC_STATIC_INFORMATION, m_strBlackInfor);
	DDX_Text(pDX, IDC_STATIC_RED_WIN_NUM, m_nRedWinNum);
	DDX_Text(pDX, IDC_STATIC_RED_LOSE_NUM, m_nRedLoseNum);
	DDX_Text(pDX, IDC_STATIC__RED_WIN_RATIO, m_nRedWinRatio);
	DDX_Text(pDX, IDC_STATIC_RED_INFORMATION, m_strRedInfor);
}

BEGIN_MESSAGE_MAP(CChineseChessDlg, CDialog)
	//{{AFX_MSG_MAP(CChineseChessDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_LBUTTONDOWN()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON_START, &CChineseChessDlg::OnBnClickedButtonStart)
	ON_WM_MOUSEMOVE()
	ON_COMMAND(ID_DRAW_CHESSBOARD, &CChineseChessDlg::OnDrawChessboard)
	ON_UPDATE_COMMAND_UI(ID_DRAW_CHESSBOARD, &CChineseChessDlg::OnUpdateDrawChessboard)
	ON_COMMAND(ID_DRAW_CHESSBOARD_BY_BITMAP, &CChineseChessDlg::OnDrawChessboardByBitmap)
	ON_UPDATE_COMMAND_UI(ID_DRAW_CHESSBOARD_BY_BITMAP, &CChineseChessDlg::OnUpdateDrawChessboardByBitmap)
	ON_COMMAND(ID_DRAW_CHESSBOARD_3D, &CChineseChessDlg::OnDrawChessboard3d)
	ON_UPDATE_COMMAND_UI(ID_DRAW_CHESSBOARD_3D, &CChineseChessDlg::OnUpdateDrawChessboard3d)
	ON_WM_INITMENUPOPUP()
	ON_BN_CLICKED(IDC_BUTTON_BACKWARD, &CChineseChessDlg::OnBnClickedButtonBackward)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChineseChessDlg message handlers

BOOL CChineseChessDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CChineseChessDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CChineseChessDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
		CDC *pDC = GetDC();

		//��ʼ�����ƻ���
		static bool bInitRenderDC = false;
		if (bInitRenderDC == false)
		{
			m_render.InitRenderDC(pDC, &m_chessboard, &m_playerRed, &m_playerBlack);
			bInitRenderDC = true;
		}

		//˫����Ͳ�������
		CRect rect, clientRect;
		GetClientRect(clientRect);
		rect = m_chessboard.GetBoardRect();
		int w = rect.Width();
		int h = rect.Height();
		static bool bCreatedMemDC = false;
		if (bCreatedMemDC == false)
		{
			m_pMemDC.CreateCompatibleDC(pDC);
			m_pBitmap.CreateCompatibleBitmap(pDC, clientRect.Width(), clientRect.Height());
			m_pMemDC.SelectObject(m_pBitmap);
			bCreatedMemDC = true;
		}

		m_render.RenderAll(&m_pMemDC);

		pDC->BitBlt(rect.left, rect.top, w, h, &m_pMemDC, rect.left, rect.top, SRCCOPY);//��ͼ

		ShowInfo();

		ReleaseDC(pDC);
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CChineseChessDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CChineseChessDlg::InitGame()
{
	m_chessboard.ClearPieces();
	m_playerRed.ReStart(m_chessboard);
	m_playerBlack.ReStart(m_chessboard);
}

void CChineseChessDlg::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if (m_chessboard.PointIsInBoard(point))
	{
		CPlayer &player = CPlayer::WhoseTurn(m_playerRed, m_playerBlack);
		CPlayer &other = ( player==m_playerRed? m_playerBlack : m_playerRed);
		bool bChanged = player.ClickOn(m_render,m_chessboard, point, other);
		queue<CRect> &q = m_render.GetInvalideRects();
		while (q.empty() == false)
		{
			CRect r = q.front();
			InvalidateRect(r,FALSE);
			q.pop();
		}
		if (bChanged)
		{
			ShowInfo();
		}
	}

	CDialog::OnLButtonDown(nFlags, point);
}

void CChineseChessDlg::OnMouseMove(UINT nFlags, CPoint point)
{
	// TODO: Add your message handler code here and/or call default
	//if (m_playerBlack.HaveSelectedPiece() || m_playerRed.HaveSelectedPiece())
	//{
	//	CPlayer &player = CPlayer::WhoseTurn(m_playerRed, m_playerBlack);
	//	CPlayer &other = (player == m_playerRed ? m_playerBlack : m_playerRed);
	//	CPiece &piece = player.SelectedPiece();
	//	if (m_chessboard.PointIsInBoard(point))
	//	{
	//		CRect oldRect = piece.GetShowRect();
	//		piece.SetShowRect(point);
	//		if (oldRect.Width() > 0 )
	//			InvalidateRect(oldRect);
	//		InvalidateRect(piece.GetShowRect());
	//	}
	//}

	CDialog::OnMouseMove(nFlags, point);
}

// ��ʾ��˭����
void CChineseChessDlg::ShowInfo()
{
	CWnd *wndBlack = GetDlgItem(IDC_STATIC_INFORMATION);
	CWnd *wndRed = GetDlgItem(IDC_STATIC_RED_INFORMATION);
	
	//������ʾ������
	static bool bFontCreated = false;
	if (bFontCreated == false)
	{
		m_fontInfo.CreateFont(25, 0, 0, 0, 400, FALSE, FALSE,
			0, OEM_CHARSET, OUT_DEFAULT_PRECIS,
			CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
			DEFAULT_PITCH, _T("����"));
		wndBlack->SetFont(&m_fontInfo);
		wndRed->SetFont(&m_fontInfo);
		bFontCreated = true;
	}

	if (CChessRule::GameOver(m_playerRed))
	{
		if (m_playerRed.Status() == CPlayer::STATUS_WIN)
		{
			m_strRedInfor = _T("�췽ʤ");
			//���¸���Ӯ���䡢ʤ������
			m_nRedWinNum = m_playerRed.WinNumber();
			m_nRedWinRatio = 100.0f*m_nRedWinNum / m_playerRed.TotalNumber();
		}
		else if (m_playerBlack.Status() == CPlayer::STATUS_WIN)
		{
			m_strBlackInfor = _T("�ڷ�ʤ");
			//���¸���Ӯ���䡢ʤ������
			m_nRedWinNum = m_playerRed.WinNumber();
			m_nRedLoseNum = m_playerRed.LosedNumber();
			m_nRedWinRatio = 100.0f*m_nRedWinNum / m_playerRed.TotalNumber();
		}
		else
		{
			m_strBlackInfor = m_strRedInfor = _T("ƽ��");
		}
	}
	else
	{
		if (m_playerRed.IsMyTurn())
		{
			m_strRedInfor = _T("�췽����");
			m_strBlackInfor.Empty();
		}
		else
		{
			m_strRedInfor.Empty();
			m_strBlackInfor = _T("�ڷ�����");
		}
	}

	

	UpdateData(FALSE);
}

//��ʼ
void CChineseChessDlg::OnBnClickedButtonStart()
{
	// TODO: Add your control notification handler code here
	InitGame();
	Invalidate();
}

void CChineseChessDlg::OnDrawChessboard()
{
	// TODO: Add your command handler code here
	m_render.SetRenderType(CRender::RENDER_TYPE_DRAW);
	Invalidate();
}

void CChineseChessDlg::OnUpdateDrawChessboard(CCmdUI *pCmdUI)
{
	if (m_render.GetRenderType() == CRender::RENDER_TYPE_DRAW)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);

}


void CChineseChessDlg::OnDrawChessboardByBitmap()
{
	m_render.SetRenderType(CRender::RENDER_TYPE_BITMAP);
	Invalidate();
}


void CChineseChessDlg::OnUpdateDrawChessboardByBitmap(CCmdUI *pCmdUI)
{
	if (m_render.GetRenderType() == CRender::RENDER_TYPE_BITMAP)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}


void CChineseChessDlg::OnDrawChessboard3d()
{
	m_render.SetRenderType(CRender::RENDER_TYPE_3D);
	Invalidate();
}


void CChineseChessDlg::OnUpdateDrawChessboard3d(CCmdUI *pCmdUI)
{
	if (m_render.GetRenderType() == CRender::RENDER_TYPE_3D)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}


void CChineseChessDlg::OnInitMenuPopup(CMenu* pPopupMenu, UINT nIndex, BOOL bSysMenu)
{
	CDialog::OnInitMenuPopup(pPopupMenu, nIndex, bSysMenu);

	// TODO: Add your message handler code here
	ASSERT(pPopupMenu != NULL);
	// Check the enabled state of various menu items.

	CCmdUI state;
	state.m_pMenu = pPopupMenu;
	ASSERT(state.m_pOther == NULL);
	ASSERT(state.m_pParentMenu == NULL);

	// Determine if menu is popup in top-level menu and set m_pOther to
	// it if so (m_pParentMenu == NULL indicates that it is secondary popup).
	HMENU hParentMenu;
	if (AfxGetThreadState()->m_hTrackingMenu == pPopupMenu->m_hMenu)
		state.m_pParentMenu = pPopupMenu;    // Parent == child for tracking popup.
	else if ((hParentMenu = ::GetMenu(m_hWnd)) != NULL)
	{
		CWnd* pParent = this;
		// Child windows don't have menus--need to go to the top!
		if (pParent != NULL &&
			(hParentMenu = ::GetMenu(pParent->m_hWnd)) != NULL)
		{
			int nIndexMax = ::GetMenuItemCount(hParentMenu);
			for (int nIndex = 0; nIndex < nIndexMax; nIndex++)
			{
				if (::GetSubMenu(hParentMenu, nIndex) == pPopupMenu->m_hMenu)
				{
					// When popup is found, m_pParentMenu is containing menu.
					state.m_pParentMenu = CMenu::FromHandle(hParentMenu);
					break;
				}
			}
		}
	}

	state.m_nIndexMax = pPopupMenu->GetMenuItemCount();
	for (state.m_nIndex = 0; state.m_nIndex < state.m_nIndexMax;
		state.m_nIndex++)
	{
		state.m_nID = pPopupMenu->GetMenuItemID(state.m_nIndex);
		if (state.m_nID == 0)
			continue; // Menu separator or invalid cmd - ignore it.

		ASSERT(state.m_pOther == NULL);
		ASSERT(state.m_pMenu != NULL);
		if (state.m_nID == (UINT)-1)
		{
			// Possibly a popup menu, route to first item of that popup.
			state.m_pSubMenu = pPopupMenu->GetSubMenu(state.m_nIndex);
			if (state.m_pSubMenu == NULL ||
				(state.m_nID = state.m_pSubMenu->GetMenuItemID(0)) == 0 ||
				state.m_nID == (UINT)-1)
			{
				continue;       // First item of popup can't be routed to.
			}
			state.DoUpdate(this, TRUE);   // Popups are never auto disabled.
		}
		else
		{
			// Normal menu item.
			// Auto enable/disable if frame window has m_bAutoMenuEnable
			// set and command is _not_ a system command.
			state.m_pSubMenu = NULL;
			state.DoUpdate(this, FALSE);
		}

		// Adjust for menu deletions and additions.
		UINT nCount = pPopupMenu->GetMenuItemCount();
		if (nCount < state.m_nIndexMax)
		{
			state.m_nIndex -= (state.m_nIndexMax - nCount);
			while (state.m_nIndex < nCount &&
				pPopupMenu->GetMenuItemID(state.m_nIndex) == state.m_nID)
			{
				state.m_nIndex++;
			}
		}
		state.m_nIndexMax = nCount;
	}
}


void CChineseChessDlg::OnBnClickedButtonBackward()
{
	AfxMessageBox(_T("���Ӻ����ɷ������޻ڣ���"));
}
