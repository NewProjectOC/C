#include "stdafx.h"
#include "Render.h"
#include "Chessboard.h"
#include "piece.h"
#include "Player.h"

CRender::CRender()
{
	m_nRenderType = RENDER_TYPE_DRAW;
	m_pBitmapPieces2 = NULL;
}


CRender::~CRender()
{
	m_memBoardDC.DeleteDC();
	m_memPiecesDC.DeleteDC();
	m_bitmapBoard.DeleteObject();
	m_bitmapPieces.DeleteObject();
	if (m_pBitmapPieces2)
	{
		delete m_pBitmapPieces2;
	}
}

//������λͼ
void CRender::DrawChessboardBitmap(CDC *pDC)
{
	const CChessboard &board = *m_pChessboard;
	CRect rect = board.GetBoardRect();
	pDC->BitBlt(rect.left, rect.top, m_sizeOfBoard.cx, m_sizeOfBoard.cy,
		&m_memBoardDC, 0, 0,  SRCCOPY);

	//pDC->StretchBlt(board.m_nLeft, board.m_nTop, rect.Width(), rect.Height(),
	//	&m_memBoardDC, 0, 0, m_sizeOfBoard.cx, m_sizeOfBoard.cy, SRCCOPY);
}

//�����ӵ�λͼ
void CRender::DrawPiecesBitmap(CDC *pDC, const CPlayer& player)
{
	for (int i = 0; i < 16; i++)
	{
		if (player.GetPiece(i).IsAlive() )
			DrawPieceBitmap(pDC, player.GetPiece(i));
	}
}

//��һ�����ӵ�λͼ
void CRender::DrawPieceBitmap(CDC *pDC, const CPiece &piece)
{
	CRect rectInBmp;

	//��ɫ������������
	if (piece.m_bRed)
	{
		rectInBmp.top = 0;
		rectInBmp.bottom = m_sizeOfPiece.cy;
	}
	else
	{
		rectInBmp.top = m_sizeOfPiece.cy;
		rectInBmp.bottom = m_sizeOfPiece.cy * 2;
	}

	rectInBmp.left = m_nPieceIndexInBmp[piece.m_nType] * m_sizeOfPiece.cx;
	rectInBmp.right = rectInBmp.left + m_sizeOfPiece.cx;
	CRect rectPiece = GetPieceRect( piece );

	////��ɫ����  
	//float alpha = 0.3f;
	//ColorMatrix matrixItems =
	//{	1, 0, 0, 0, 0,
	//	0, 1, 0, 0, 0,
	//	0, 0, 1, 0, 0,
	//	0, 0, 0, alpha, 0,
	//	0, 0, 0, 0, 1
	//};

	Gdiplus::Rect rect(rectPiece.left, rectPiece.top, rectPiece.Width(), rectPiece.Height());
	Gdiplus::Graphics g(pDC->GetSafeHdc());
	
	//�����ѡ���ˣ���������
	if (piece.m_bSelected)
	{
		//ʵ�Ļ�ˢ
		Gdiplus::SolidBrush brush(Gdiplus::Color(255,127,127,0));
		g.FillRectangle(&brush, rect);
	}

	g.DrawImage(m_pBitmapPieces2, rect, 
		rectInBmp.left, rectInBmp.top, m_sizeOfPiece.cx, m_sizeOfPiece.cy, 
		Gdiplus::UnitPixel);

	//pDC->TransparentBlt(rectPiece.left, rectPiece.top, m_sizeOfPiece.cx, m_sizeOfPiece.cy,
	//	&m_memPiecesDC, rectInBmp.left, rectInBmp.top, m_sizeOfPiece.cx, m_sizeOfPiece.cy, 
	//	RGB(255, 255, 255));
	//pDC->BitBlt(rectPiece.left, rectPiece.top, m_sizeOfPiece.cx, m_sizeOfPiece.cy,
	//	&m_memPiecesDC, rectInBmp.left, rectInBmp.top, SRCCOPY);

}

void CRender::DrawChessboard(CDC *pDC)
{
	const CChessboard &board = *m_pChessboard;
	CRect rect = board.GetBoardRect();
	int w = rect.Width();
	int h = rect.Height();

	pDC->FillSolidRect(rect.left, rect.top, w, h, RGB(255, 255, 255));//����


	// �����̷���
	CPen penRed2(PS_SOLID, 2, RGB(255, 0, 0));
	CPen *pOldPen = pDC->SelectObject(&penRed2);
	for (int i = 0; i<10; i++)
	{
		pDC->MoveTo(board.m_nLeft, board.m_nTop + i*board.m_ndy);
		pDC->LineTo(board.m_nRight, board.m_nTop + i*board.m_ndy);
	}
	for (int i = 0; i<9; i++)
	{
		if (i == 0 || i == 8)
		{
			pDC->MoveTo(board.m_nLeft + i*board.m_ndx, board.m_nTop);
			pDC->LineTo(board.m_nLeft + i*board.m_ndx, board.m_nBottom);
		}
		else{
			pDC->MoveTo(board.m_nLeft + i*board.m_ndx, board.m_nTop);
			pDC->LineTo(board.m_nLeft + i*board.m_ndx, board.m_nTop + 4 * board.m_ndy);
			pDC->MoveTo(board.m_nLeft + i*board.m_ndx, board.m_nTop + 5 * board.m_ndy);
			pDC->LineTo(board.m_nLeft + i*board.m_ndx, board.m_nBottom);
		}
	}
	// ������б��
	pDC->SelectObject(pOldPen);
	CPen penRed1(PS_SOLID, 1, RGB(255, 0, 0));
	pOldPen = pDC->SelectObject(&penRed1);
	pDC->MoveTo(board.m_nLeft + 3 * board.m_ndx, board.m_nTop);
	pDC->LineTo(board.m_nLeft + 5 * board.m_ndx, board.m_nTop + 2 * board.m_ndy);
	pDC->MoveTo(board.m_nLeft + 3 * board.m_ndx, board.m_nTop + 2 * board.m_ndy);
	pDC->LineTo(board.m_nLeft + 5 * board.m_ndx, board.m_nTop);
	pDC->MoveTo(board.m_nLeft + 3 * board.m_ndx, board.m_nBottom);
	pDC->LineTo(board.m_nLeft + 5 * board.m_ndx, board.m_nBottom - 2 * board.m_ndy);
	pDC->MoveTo(board.m_nLeft + 3 * board.m_ndx, board.m_nBottom - 2 * board.m_ndy);
	pDC->LineTo(board.m_nLeft + 5 * board.m_ndx, board.m_nBottom);
	pDC->SelectObject(pOldPen);
	// ����, ��λ���
	DrawConer(pDC, 2, 1, 0);
	DrawConer(pDC, 2, 7, 0);
	DrawConer(pDC, 3, 0, 1);
	DrawConer(pDC, 3, 2, 0);
	DrawConer(pDC, 3, 4, 0);
	DrawConer(pDC, 3, 6, 0);
	DrawConer(pDC, 3, 8, 2);
	DrawConer(pDC, 7, 1, 0);
	DrawConer(pDC, 7, 7, 0);
	DrawConer(pDC, 6, 0, 1);
	DrawConer(pDC, 6, 2, 0);
	DrawConer(pDC, 6, 4, 0);
	DrawConer(pDC, 6, 6, 0);
	DrawConer(pDC, 6, 8, 2);
}
// ���Ʊ�, ��λ��־
void CRender::DrawConer(CDC *pDC, int row, int col, int type)
{
	const CChessboard &board = *m_pChessboard;

	CPen penRed1(PS_SOLID, 1, RGB(255, 0, 0));
	CPen *pOldPen = pDC->SelectObject(&penRed1);
	if (type == 0 || type == 1)
	{
		pDC->MoveTo(board.m_nLeft + col*board.m_ndx + 3, board.m_nTop + row*board.m_ndy - 10);
		pDC->LineTo(board.m_nLeft + col*board.m_ndx + 3, board.m_nTop + row*board.m_ndy - 3);
		pDC->LineTo(board.m_nLeft + col*board.m_ndx + 10, board.m_nTop + row*board.m_ndy - 3);
		pDC->MoveTo(board.m_nLeft + col*board.m_ndx + 3, board.m_nTop + row*board.m_ndy + 10);
		pDC->LineTo(board.m_nLeft + col*board.m_ndx + 3, board.m_nTop + row*board.m_ndy + 3);
		pDC->LineTo(board.m_nLeft + col*board.m_ndx + 10, board.m_nTop + row*board.m_ndy + 3);
	}
	if (type == 0 || type == 2)
	{
		pDC->MoveTo(board.m_nLeft + col*board.m_ndx - 3, board.m_nTop + row*board.m_ndy - 10);
		pDC->LineTo(board.m_nLeft + col*board.m_ndx - 3, board.m_nTop + row*board.m_ndy - 3);
		pDC->LineTo(board.m_nLeft + col*board.m_ndx - 10, board.m_nTop + row*board.m_ndy - 3);
		pDC->MoveTo(board.m_nLeft + col*board.m_ndx - 3, board.m_nTop + row*board.m_ndy + 10);
		pDC->LineTo(board.m_nLeft + col*board.m_ndx - 3, board.m_nTop + row*board.m_ndy + 3);
		pDC->LineTo(board.m_nLeft + col*board.m_ndx - 10, board.m_nTop + row*board.m_ndy + 3);
	}
	pDC->SelectObject(pOldPen);
}


void CRender::DrawPieces(CDC *pDC, const CPlayer& player)
{
	// ׼�������ӵĻ��ʺͻ�ˢ
	CPen *pOldPen, penNormal(PS_SOLID, 3, RGB(120, 120, 120));
	CBrush *pOldBrush, brushNormal, brushSelected;
	brushNormal.CreateSolidBrush(RGB(255, 255, 0));
	brushSelected.CreateSolidBrush(RGB(127, 127, 0));
	pOldPen = pDC->SelectObject(&penNormal);

	// ׼����ʾ�������Ƶ�����
	CFont *pOldFont, fontStone;
	fontStone.CreateFont(40, 0, 0, 0, 400, FALSE, FALSE,
		0, OEM_CHARSET, OUT_DEFAULT_PRECIS,
		CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
		DEFAULT_PITCH, _T("����"));
	pOldFont = pDC->SelectObject(&fontStone);

	for (int i = 0; i < 16; i++)
	{
		const CPiece &piece = player.GetPiece(i);

		// ֻ��δ���Ե������Ӳ���ʾ
		if (piece.IsKilled() == true)
			continue;
	

		// ��ѡ�е�������ɫ��ͬ
		if (piece.m_bSelected)
			pOldBrush = pDC->SelectObject(&brushSelected);
		else
			pOldBrush = pDC->SelectObject(&brushNormal);

		// ��ʾ����ԭ��λ�ã���4����
		CRect rectPiece = GetPieceRect(piece);
		CRect r(rectPiece);

		//if ( m_bSelected )
		//{
		//	pDC->MoveTo(r.left, r.top);
		//	pDC->LineTo(r.right, r.top);
		//	pDC->LineTo(r.right, r.bottom);
		//	pDC->LineTo(r.left, r.bottom);
		//	pDC->LineTo(r.left, r.top);
		//	//r = m_rectShow;
		//}

		//����ǰ��ʾ��λ��

		r.left++;
		r.top++;
		r.right--;
		r.bottom--;
		pDC->Ellipse(r);
		pDC->SelectObject(pOldBrush);

		int tx = rectPiece.left + 6;
		int ty = rectPiece.top + 6;

		pDC->SetBkMode(TRANSPARENT);

		// ���ӱ�����Ϊ��ɫ���ַֺ졢����ɫ
		pDC->SetTextColor(RGB(piece.m_bRed ? 255 : 0, 0, 0));
		pDC->TextOut(tx, ty, piece.m_sName);
	}
	
	pDC->SelectObject(pOldPen);
	pDC->SelectObject(pOldFont);	
}
void CRender::DrawPiece(CDC *pDC, const CPiece& piece)
{
	if (piece.IsAlive() )	// ֻ��δ���Ե������Ӳ���ʾ
	{
		// ׼�������ӵĻ��ʺͻ�ˢ
		CPen *pOldPen, penNormal(PS_SOLID, 3, RGB(120, 120, 120));
		CBrush *pOldBrush, brushNormal, brushSelected;
		brushNormal.CreateSolidBrush(RGB(255, 255, 0));
		brushSelected.CreateSolidBrush(RGB(127, 127, 0));
		pOldPen = pDC->SelectObject(&penNormal);
		// ��ѡ�е�������ɫ��ͬ
		if (piece.m_bSelected)
			pOldBrush = pDC->SelectObject(&brushSelected);
		else
			pOldBrush = pDC->SelectObject(&brushNormal);

		// ��ʾ����ԭ��λ�ã���4����
		CRect rectPiece = GetPieceRect(piece);
		CRect r(rectPiece);

		//if ( m_bSelected )
		//{
		//	pDC->MoveTo(r.left, r.top);
		//	pDC->LineTo(r.right, r.top);
		//	pDC->LineTo(r.right, r.bottom);
		//	pDC->LineTo(r.left, r.bottom);
		//	pDC->LineTo(r.left, r.top);
		//	//r = m_rectShow;
		//}

		//����ǰ��ʾ��λ��

		r.left++;
		r.top++;
		r.right--;
		r.bottom--;
		pDC->Ellipse(r);
		pDC->SelectObject(pOldPen);
		pDC->SelectObject(pOldBrush);
		// ׼����ʾ�������Ƶ�����
		CFont *pOldFont, fontStone;
		fontStone.CreateFont(40, 0, 0, 0, 400, FALSE, FALSE,
			0, OEM_CHARSET, OUT_DEFAULT_PRECIS,
			CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
			DEFAULT_PITCH, _T("����"));
		pOldFont = pDC->SelectObject(&fontStone);
		int tx = rectPiece.left + 6;
		int ty = rectPiece.top + 6;
		pDC->SetBkMode(TRANSPARENT);
		// ���ӱ�����Ϊ��ɫ���ַֺ졢����ɫ
		pDC->SetTextColor(RGB(piece.m_bRed ? 255 : 0, 0, 0));
		pDC->TextOut(tx, ty, piece.m_sName);
		pDC->SelectObject(pOldFont);
	}
}

//��ʾ����
void CRender::ShowChessboard(CDC *pDC)
{
	switch (m_nRenderType)
	{
	case RENDER_TYPE_DRAW:
		DrawChessboard(pDC);
		break;
	case RENDER_TYPE_BITMAP:
		DrawChessboardBitmap(pDC);
		break;
	case RENDER_TYPE_3D:
		break;
	default:
		break;
	}

}

//��ʾ��ҵ���������
void CRender::ShowPieces(CDC *pDC, const CPlayer& player)
{
	switch (m_nRenderType)
	{
	case RENDER_TYPE_DRAW:
		DrawPieces(pDC, player);
		break;
	case RENDER_TYPE_BITMAP:
		DrawPiecesBitmap(pDC, player);
		break;
	case RENDER_TYPE_3D:
		break;
	default:
		break;
	}
}

//��ʾһ������
void CRender::ShowPiece(CDC *pDC, const CPiece& piece)
{
	switch (m_nRenderType)
	{
	case RENDER_TYPE_DRAW:
		DrawPiece(pDC,piece);
		break;
	case RENDER_TYPE_BITMAP:
		break;
	case RENDER_TYPE_3D:
		break;
	default:
		break;
	}
}

//��ʼ�����ƻ���
void CRender::InitRenderDC(CDC * pDC, CChessboard *board, CPlayer *red, CPlayer *black)
{
	m_pDC = pDC;
	m_pChessboard = board;
	m_pPlayerRed = red;
	m_pPlayerBlack = black;

	m_memBoardDC.CreateCompatibleDC(pDC);
	m_bitmapBoard.LoadBitmap(IDB_BITMAP_CHESSBOARD);
	m_memBoardDC.SelectObject(&m_bitmapBoard);
	BITMAP bmInfo;
	m_bitmapBoard.GetObject(sizeof(bmInfo), &bmInfo);
	m_sizeOfBoard.SetSize(bmInfo.bmWidth, bmInfo.bmHeight);

	m_memPiecesDC.CreateCompatibleDC(pDC);
	m_bitmapPieces.LoadBitmap(IDB_BITMAP_PIECES);
	m_memPiecesDC.SelectObject(&m_bitmapPieces);

	//Ϊÿ����������͸���ȣ�λͼ�е�Բ��������Χ�ǰ�ɫ�ģ����Ұ�ɫ��RGBֵ��һ�����䣬���ǹ̶���һ��ֵ��255,255,255��
	m_pBitmapPieces2 = new Gdiplus::Bitmap(m_sizeOfBoard.cx, m_sizeOfBoard.cy, PixelFormat32bppARGB);
	Gdiplus::Color colorSrc, colorDst;
	BYTE alpha; //͸���ȣ�255��ʾ��͸����0��ʾȫ͸��
	
	//����λͼ
	Gdiplus::Bitmap src(AfxFindResourceHandle(MAKEINTRESOURCE(IDB_BITMAP_PIECES), RT_BITMAP), MAKEINTRESOURCE(IDB_BITMAP_PIECES));

	//������ص�����͸������Ϣ��255��͸����0ȫ͸��
	for (int y = 0; y < m_sizeOfBoard.cy; y++)
	for (int x = 0; x < m_sizeOfBoard.cx; x++)
	{
		src.GetPixel(x, y, &colorSrc);
		//͸����alpha = 255-��ǰ������
		alpha = ( colorSrc.GetRed() + colorSrc.GetGreen() + colorSrc.GetBlue() ) / 3; 
		if (alpha > 200)
			alpha = 255 - alpha;
		else
			alpha = 255;
		colorDst = Gdiplus::Color(
			alpha, 
			colorSrc.GetRed(),
			colorSrc.GetGreen(),
			colorSrc.GetBlue()
			);
		m_pBitmapPieces2->SetPixel(x, y, colorDst);
	}
	
	//������λͼ�еĳߴ�Ϊ50*50
	m_sizeOfPiece.SetSize(50,50);
	
	//λͼ�е�˳��
	//0-JIANG, 1-SHI,2-PAO,3-MA,4-XIANG,5-JU,6-BING
	//������λͼ������˳��Ķ�Ӧ��ϵ
	m_nPieceIndexInBmp[CPiece::PIECE_TYPE_JIANG] = 0;
	m_nPieceIndexInBmp[CPiece::PIECE_TYPE_SHI] = 1;
	m_nPieceIndexInBmp[CPiece::PIECE_TYPE_PAO] = 2;
	m_nPieceIndexInBmp[CPiece::PIECE_TYPE_MA] = 3;
	m_nPieceIndexInBmp[CPiece::PIECE_TYPE_XIANG] = 4;
	m_nPieceIndexInBmp[CPiece::PIECE_TYPE_JU] = 5;
	m_nPieceIndexInBmp[CPiece::PIECE_TYPE_BING] = 6;

	CSize boardSize = GetBoardBmpSize();
	m_pChessboard->SetBoardRect2(m_pChessboard->GetBoardLeft(), m_pChessboard->GetBoardTop(), boardSize.cx, boardSize.cy);
	m_nPiecesRadius = m_pChessboard->GetPiecesSpaceX()*0.46;
}

CSize CRender::GetBoardBmpSize()
{
	return m_sizeOfBoard;
}

//�������г���
void CRender::RenderAll(CDC *pDC)
{
	ShowChessboard(pDC);
	ShowPieces(pDC, *m_pPlayerRed);
	ShowPieces(pDC, *m_pPlayerBlack);
}


// ���ӵľ�������
CRect CRender::GetPieceRect(const CPiece& piece)const
{
	const int &r = m_nPiecesRadius;
	CPoint pos = m_pChessboard->GetPosition( piece.GetPosition() );
	return CRect(pos.x - r, pos.y - r, pos.x + r, pos.y + r);
}
