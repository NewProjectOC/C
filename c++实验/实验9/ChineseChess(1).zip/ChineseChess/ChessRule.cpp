#include "stdafx.h"
#include "ChessRule.h"
#include "Chessboard.h"
#include "piece.h"
#include "Player.h"


CChessRule::CChessRule()
{
}


CChessRule::~CChessRule()
{
}

//�ж�chessType���͵����Ӵ�λ��from��λ��to���Ƿ�����
bool CChessRule::CanMoveTo(INOUT CPiece &piece, IN const CPoint &from, IN const CPoint &to, IN const CChessboard &board, OUT string &strMsg)
{
	switch (piece.GetType())
	{
	case CPiece::PIECE_TYPE_JU:
		return JU(piece, from, to, board, strMsg);
		break;

	case CPiece::PIECE_TYPE_MA:
		return MA(piece, from, to, board, strMsg);
		break;

	case CPiece::PIECE_TYPE_PAO:
		return PAOMove(piece, from, to, board, strMsg);
		break;
	case CPiece::PIECE_TYPE_JIANG:
		return JIANG(piece, from, to, board, strMsg);
		break;
	case CPiece::PIECE_TYPE_SHI:
		return SHI(piece, from, to, board, strMsg);
		break;
	case CPiece::PIECE_TYPE_XIANG:
		return XIANG(piece, from, to, board, strMsg);
		break;
	case CPiece::PIECE_TYPE_BING:
		return BING(piece, from, to, board, strMsg);
		break;
	default:
		return false;
	}

	return true;
}

//�ж�chessType���͵����Ӵ�λ��from��λ��to���Ƿ�����
bool CChessRule::CanEat(INOUT CPiece &piece, IN const CPoint &from, IN const CPoint &to, IN const CChessboard &board, OUT string &strMsg)
{
	switch (piece.GetType())
	{
	case CPiece::PIECE_TYPE_JU:
		return JU(piece, from, to, board, strMsg);
		break;

	case CPiece::PIECE_TYPE_MA:
		return MA(piece, from, to, board, strMsg);
		break;

	case CPiece::PIECE_TYPE_PAO:
		return PAOEat(piece, from, to, board, strMsg);
		break;
	case CPiece::PIECE_TYPE_JIANG:
		return JIANG(piece, from, to, board, strMsg);
		break;
	case CPiece::PIECE_TYPE_SHI:
		return SHI(piece, from, to, board, strMsg);
		break;
	case CPiece::PIECE_TYPE_XIANG:
		return XIANG(piece, from, to, board, strMsg);
		break;
	case CPiece::PIECE_TYPE_BING:
		return BING(piece, from, to, board, strMsg);
		break;
	default:
		return false;
	}

	return true;
}


bool CChessRule::GameOver(const CPlayer &player)
{
	if (player.Status() >= CPlayer::STATUS_END)
		return true;
	else
		return false;
}

//����������򣬷���ֵ��true��ʾ�����ߣ�false��ʾ������
bool CChessRule::JU(INOUT CPiece &piece, IN const CPoint &from, IN const CPoint &to, IN const CChessboard &board, OUT string &strMsg)
{
	//from��to������ֱ����
	CPoint dis = to - from;
	if (dis.x != 0 && dis.y != 0)
		return false;

	//�м��Ƿ��������赲
	if (dis.x == 0)
	{
		int dy = dis.y > 0 ? 1 : -1;
		for (int y = from.y + dy; y != to.y; y += dy)
			if (board.HavePiece(CPoint(to.x, y)))
				return false;
	}
	else if (dis.y == 0)
	{
		int dx = dis.x > 0 ? 1 : -1;
		for (int x = from.x + dx; x != to.x; x += dx)
			if (board.HavePiece(CPoint(x, to.y)))
				return false;
	}
	return true;
}

//�ڵ��ƶ��ͳ���һ����
bool CChessRule::PAOMove(INOUT CPiece &piece, IN const CPoint &from, IN const CPoint &to, IN const CChessboard &board, OUT string &strMsg)
{
	return JU(piece, from, to, board, strMsg);
}

bool CChessRule::PAOEat(INOUT CPiece &piece, IN const CPoint &from, IN const CPoint &to, IN const CChessboard &board, OUT string &strMsg)
{
	//from��to������ֱ����
	CPoint dis = to - from;
	if (dis.x != 0 && dis.y != 0)
		return false;

	//�м������һ�����Ӹ���
	if (dis.x == 0)
	{
		int count = 0;
		int dy = dis.y > 0 ? 1 : -1;
		for (int y = from.y + dy; y != to.y; y += dy)
		{
			if (board.HavePiece(CPoint(to.x, y)))
				count++;
		}
		return ( count == 1 ? true : false );
	}
	else if (dis.y == 0)
	{
		int count = 0;
		int dx = dis.x > 0 ? 1 : -1;
		for (int x = from.x + dx; x != to.x; x += dx)
		{
			if (board.HavePiece(CPoint(x, to.y)))
				count++;
		}
		return (count == 1 ? true : false);
	}
}

//����������򣬷���ֵ��true��ʾ�����ߣ�false��ʾ������
bool CChessRule::MA(INOUT CPiece &piece, IN const CPoint &from, IN const CPoint &to, IN const CChessboard &board, OUT string &strMsg)
{
	CPoint dis = to - from;

	//����������
	if (abs(dis.x) + abs(dis.y) != 3)
		return false;

	//������û�б���ס
	if (abs(dis.y) == 2)
	{
		if (board.HavePiece(CPoint(from.x, from.y + dis.y/2)))
			return false;
	}
	else if (abs(dis.x) == 2)
	{
		if (board.HavePiece(CPoint(from.x + dis.x / 2, from.y)))
			return false;
	}
	return true;
}


bool CChessRule::XIANG(INOUT CPiece &piece, IN const CPoint &from, IN const CPoint &to, IN const CChessboard &board, OUT string &strMsg)
{
	CPoint dis = to - from;

	//����������
	if (abs(dis.x) != 2 || abs(dis.y) != 2)
		return false;

	//ֻ���ڱ�������
	if (piece.IsRed() && !board.IsInRedRegion(to))
		return false;
	if (!piece.IsRed() && board.IsInRedRegion(to))
		return false;
	return true;
}

bool CChessRule::SHI(INOUT CPiece &piece, IN const CPoint &from, IN const CPoint &to, IN const CChessboard &board, OUT string &strMsg)
{
	//�췽��ʿ
	if (piece.IsRed())
	{
		if (to.x < 3 || to.x > 5 || to.y > 2)
			return false;
		CPoint dis = to - from;
		if (abs(dis.x) != 1 || abs(dis.y) != 1)
			return false;
		return true;
	}
	else
	{
		if (to.x < 3 || to.x > 5 || to.y < 7)
			return false;
		CPoint dis = to - from;
		if (abs(dis.x) != 1 || abs(dis.y) != 1)
			return false;
		return true;
	}
}

bool CChessRule::JIANG(INOUT CPiece &piece, IN const CPoint &from, IN const CPoint &to, IN const CChessboard &board, OUT string &strMsg)
{
	//�췽
	if (piece.IsRed())
	{
		if (to.x < 3 || to.x > 5 || to.y > 2)
			return false;
		CPoint dis = to - from;
		if ( abs(dis.x) + abs(dis.y) != 1 )
			return false;
		return true;
	}
	else
	{
		if (to.x < 3 || to.x > 5 || to.y < 7)
			return false;
		CPoint dis = to - from;
		if ( abs(dis.x) + abs(dis.y) != 1)
			return false;
		return true;
	}
}

bool CChessRule::BING(INOUT CPiece &piece, IN const CPoint &from, IN const CPoint &to, IN const CChessboard &board, OUT string &strMsg)
{
	//�췽
	if (piece.IsRed())
	{
		CPoint dis = to - from;
		if (board.IsInRedRegion(to))
		{
			if (dis.x != 0 || dis.y <= 0 || dis.y > 1 )
				return false;
			return true;
		}
		else
		{
			if (dis.y < 0 || dis.y > 1 || abs(dis.x) + abs(dis.y) != 1)
				return false;
			return true;
		}
	}
	//�ڷ��ı�
	else
	{
		CPoint dis = to - from;
		if (!board.IsInRedRegion(to))
		{
			if (dis.x != 0 || dis.y >= 0 || dis.y < -1)
				return false;
			return true;
		}
		else
		{
			if (dis.y > 0 || abs(dis.x) + abs(dis.y) != 1)
				return false;
			return true;
		}
	}
}

